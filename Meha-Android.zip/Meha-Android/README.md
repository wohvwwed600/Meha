# Meha for Android

Two ways to get Meha on an Android phone. Your points, medals, decorations, streaks and profile
are saved on the device.

## Option A - install it as an app (no Android Studio, about 2 minutes)
1. Upload the `web/` folder to any HTTPS static host (Netlify Drop, GitHub Pages, Cloudflare Pages).
2. Open the link in Chrome on your phone.
3. Menu (three dots) > **Install app** (or **Add to Home screen**). Meha appears as its own app and works offline.

## Option B - build an APK
1. Install Android Studio and open the `Meha-Android` folder (it downloads Gradle and the SDK itself).
2. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Copy `app/build/outputs/apk/debug/app-debug.apk` to the phone, tap it, and allow "install unknown apps".
   To publish on Google Play use **Build > Generate Signed Bundle / APK** and choose Android App Bundle.

The app is a thin WebView wrapper (`MainActivity.java`) around `app/src/main/assets/index.html`,
the same file as `web/index.html`. Edit that file and rebuild to change the app.

## Option C - APK from a hosted link
Host `web/` as in Option A, then paste the URL into pwabuilder.com and choose Android.

## Notes
- GIF avatar/banner: GIFs up to 6 MB keep their animation while the app is open. Android only remembers about 5 MB of saved data in total, so a very large GIF may need to be picked again after a restart. Bigger files fall back to a still image.
- "Preview tomorrow's tasks" on the Today tab moves the app one day ahead for testing.
